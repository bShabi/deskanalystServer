import React from 'react';
import loginImg from '../../login.svg';
import '../css/App.css';
import axios from 'axios';
import { withRouter } from 'react-router';
import { toast } from 'react-toastify';
import { connect } from 'react-redux'
import { getGamesByTeamId } from '../../redux/action/games'

class _LoginPage extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      redirect: false,
      email: '',
      password: '',
      nameTeam: '',
    };
    this.onSubmit = this.onSubmit.bind(this);
    this.onChange = this.onChange.bind(this);
  }
  componentDidMount() {
    const user = JSON.parse(sessionStorage.getItem("loginUser"))
    if (user) {
      this.props.history.push('/Dashboard')
    }
    toast.configure();
  }

  onChange(name, value) {
    this.setState({
      [name]: value,
    });
  }
  onSubmit = (ev) => {
    ev.preventDefault()
    axios
      .post('http://localhost:5000/users/login', {
        email: this.state.email,
        password: this.state.password,
      })
      .then(
        (response) => {
          console.log(response);
          if (response.data === null) {
            toast.error('email or password is incorrect');
          } else {
            console.log(response.data);
            sessionStorage.setItem('loginUser', JSON.stringify(response.data));
            console.log(response.data.permission)
            this.setState({
              nameTeam: response.data.nameTeam,
            });
            this.props.getGamesByTeamId(response.data.teamid)
              .then(() => {
                this.props.history.push('/Dashboard');
                toast.success('success');
                window.location.reload(false);
              })
          }
        },
        (error) => {
          console.log(error);
        }
      );
  }

  render() {
    return (
      <form action='onSubmit'>
        <div className='base-container'>
          <div className='header'> </div>{' '}
          <div className='content'>
            <div className='image'>
              <img
                src={loginImg}
                style={{
                  width: '50%',
                  height: '50%',
                }}
              />{' '}
            </div>{' '}
            <div className='form'>
              <div className='form-group'>
                <label htmlFor='username'> Username </label>{' '}
                <input
                  type='text'
                  name='email'
                  placeholder='Email'
                  onChange={(e) => this.onChange(e.target.name, e.target.value)}
                />{' '}
              </div>{' '}
              <div className='form-group'>
                <label htmlFor='password'> Password </label>{' '}
                <input
                  type='password'
                  name='password'
                  placeholder='Password'
                  onChange={(e) => this.onChange(e.target.name, e.target.value)}
                />{' '}
              </div>{' '}
            </div>{' '}
          </div>
          <div className='footer'>
            <button onClick={this.onSubmit} type='button' className='btn'>
              Login{' '}
            </button>{' '}
          </div>{' '}
        </div>{' '}
      </form>
    );
  }
}

export function nameTeam() {
  return this.state.nameTeam
}


const mapStateToProps = state => {
  return {
    games: state.games.games,
  }
}
const mapDispatchToProps = {
  getGamesByTeamId,
}
export const LoginPage = connect(mapStateToProps, mapDispatchToProps)(withRouter(_LoginPage));